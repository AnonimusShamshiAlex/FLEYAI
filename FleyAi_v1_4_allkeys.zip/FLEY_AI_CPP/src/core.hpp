// FLEY AI - переносимое ядро (без Windows API): JSON, .env, WAV, multipart, VAD, тексты ошибок.
// Тестируется отдельно: tests/test_core.cpp
#pragma once
#include <algorithm>
#include <complex>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <deque>
#include <initializer_list>
#include <map>
#include <string>
#include <vector>

namespace fley {

// ---------------------------------------------------------------- JSON
struct Json {
    enum Type { Null, Bool, Num, Str, Arr, Obj };
    Type t = Null;
    bool b = false;
    double n = 0;
    std::string s;
    std::vector<Json> a;
    std::vector<std::string> keys;
    std::vector<Json> vals;

    const Json& operator[](const std::string& k) const {
        static const Json nul;
        for (size_t i = 0; i < keys.size(); ++i)
            if (keys[i] == k) return vals[i];
        return nul;
    }
    const Json& at(size_t i) const {
        static const Json nul;
        return i < a.size() ? a[i] : nul;
    }
    std::string str() const { return t == Str ? s : std::string(); }
    bool is_obj() const { return t == Obj; }
};

inline void append_utf8(std::string& out, uint32_t cp) {
    if (cp < 0x80) out += (char)cp;
    else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
    else { out += (char)(0xF0 | (cp >> 18)); out += (char)(0x80 | ((cp >> 12) & 0x3F)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
}

class JsonParser {
public:
    explicit JsonParser(const std::string& text) : p_(text.data()), end_(text.data() + text.size()) {}
    bool parse(Json& out) {
        ws();
        if (!value(out, 0)) return false;
        ws();
        return true;
    }

private:
    const char* p_;
    const char* end_;

    void ws() { while (p_ < end_ && (*p_ == ' ' || *p_ == '\t' || *p_ == '\n' || *p_ == '\r')) ++p_; }
    bool lit(const char* w) {
        size_t n = std::strlen(w);
        if ((size_t)(end_ - p_) < n || std::strncmp(p_, w, n) != 0) return false;
        p_ += n;
        return true;
    }
    bool hex4(uint32_t& v) {
        if (end_ - p_ < 4) return false;
        v = 0;
        for (int i = 0; i < 4; ++i) {
            char c = *p_++;
            v <<= 4;
            if (c >= '0' && c <= '9') v |= (uint32_t)(c - '0');
            else if (c >= 'a' && c <= 'f') v |= (uint32_t)(c - 'a' + 10);
            else if (c >= 'A' && c <= 'F') v |= (uint32_t)(c - 'A' + 10);
            else return false;
        }
        return true;
    }
    bool string(std::string& out) {
        if (p_ >= end_ || *p_ != '"') return false;
        ++p_;
        while (p_ < end_) {
            char c = *p_++;
            if (c == '"') return true;
            if (c != '\\') { out += c; continue; }
            if (p_ >= end_) return false;
            char e = *p_++;
            switch (e) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u': {
                    uint32_t cp;
                    if (!hex4(cp)) return false;
                    if (cp >= 0xD800 && cp <= 0xDBFF && end_ - p_ >= 6 && p_[0] == '\\' && p_[1] == 'u') {
                        const char* save = p_;
                        p_ += 2;
                        uint32_t lo;
                        if (hex4(lo) && lo >= 0xDC00 && lo <= 0xDFFF) cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                        else p_ = save;
                    }
                    append_utf8(out, cp);
                    break;
                }
                default: return false;
            }
        }
        return false;
    }
    bool value(Json& out, int depth) {
        if (depth > 64 || p_ >= end_) return false;
        char c = *p_;
        if (c == '{') {
            ++p_;
            out.t = Json::Obj;
            ws();
            if (p_ < end_ && *p_ == '}') { ++p_; return true; }
            for (;;) {
                ws();
                std::string k;
                if (!string(k)) return false;
                ws();
                if (p_ >= end_ || *p_ != ':') return false;
                ++p_;
                ws();
                Json v;
                if (!value(v, depth + 1)) return false;
                out.keys.push_back(k);
                out.vals.push_back(v);
                ws();
                if (p_ < end_ && *p_ == ',') { ++p_; continue; }
                if (p_ < end_ && *p_ == '}') { ++p_; return true; }
                return false;
            }
        }
        if (c == '[') {
            ++p_;
            out.t = Json::Arr;
            ws();
            if (p_ < end_ && *p_ == ']') { ++p_; return true; }
            for (;;) {
                ws();
                Json v;
                if (!value(v, depth + 1)) return false;
                out.a.push_back(v);
                ws();
                if (p_ < end_ && *p_ == ',') { ++p_; continue; }
                if (p_ < end_ && *p_ == ']') { ++p_; return true; }
                return false;
            }
        }
        if (c == '"') { out.t = Json::Str; return string(out.s); }
        if (c == 't') { out.t = Json::Bool; out.b = true; return lit("true"); }
        if (c == 'f') { out.t = Json::Bool; out.b = false; return lit("false"); }
        if (c == 'n') { out.t = Json::Null; return lit("null"); }
        std::string num;
        while (p_ < end_ && std::strchr("+-0123456789.eE", *p_)) num += *p_++;
        if (num.empty()) return false;
        out.t = Json::Num;
        out.n = std::strtod(num.c_str(), nullptr);
        return true;
    }
};

inline bool json_parse(const std::string& text, Json& out) {
    out = Json();
    return JsonParser(text).parse(out);
}

inline std::string json_escape(const std::string& in) {
    std::string o;
    o.reserve(in.size() + 8);
    for (unsigned char c : in) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof buf, "\\u%04x", c);
                    o += buf;
                } else o += (char)c;
        }
    }
    return o;
}

// ---------------------------------------------------------------- текст
inline std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) ++a;
    while (b > a && std::isspace((unsigned char)s[b - 1])) --b;
    return s.substr(a, b - a);
}

inline std::string to_lower_ascii(std::string s) {
    for (auto& c : s) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return s;
}

// убирает markdown-символы, мешающие озвучке
inline std::string clean_text(const std::string& in) {
    std::string o;
    for (char c : in) if (c != '*' && c != '_' && c != '`' && c != '#' && c != '>') o += c;
    std::string r;
    int nl = 0;
    for (char c : o) {
        if (c == '\n') { if (++nl > 2) continue; }
        else if (c != '\r') nl = 0;
        r += c;
    }
    return trim(r);
}

// есть ли в тексте кириллица (для выбора русского голоса)
inline bool has_cyrillic(const std::string& s) {
    for (unsigned char c : s) if (c == 0xD0 || c == 0xD1) return true;
    return false;
}

// обрезка UTF-8 по границе символа
inline std::string utf8_truncate(const std::string& s, size_t max_bytes) {
    if (s.size() <= max_bytes) return s;
    size_t n = max_bytes;
    while (n > 0 && ((unsigned char)s[n] & 0xC0) == 0x80) --n;
    return s.substr(0, n);
}

// ---------------------------------------------------------------- .env и настройки
inline std::map<std::string, std::string> parse_env(const std::string& text) {
    std::map<std::string, std::string> m;
    std::string t = text;
    if (t.size() >= 3 && (unsigned char)t[0] == 0xEF && (unsigned char)t[1] == 0xBB && (unsigned char)t[2] == 0xBF) t.erase(0, 3);
    size_t pos = 0;
    while (pos <= t.size()) {
        size_t e = t.find('\n', pos);
        if (e == std::string::npos) e = t.size();
        std::string line = trim(t.substr(pos, e - pos));
        pos = e + 1;
        if (line.empty() || line[0] == '#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = trim(line.substr(0, eq)), v = trim(line.substr(eq + 1));
        if (v.size() >= 2 && ((v.front() == '"' && v.back() == '"') || (v.front() == '\'' && v.back() == '\'')))
            v = v.substr(1, v.size() - 2);
        m[k] = v;
    }
    return m;
}

struct Settings {
    std::string key, host, base_path, model, stt, tts, voice;
    std::string win_voice, call_me, effort;  // имя голоса Windows, обращение («сэр»), глубина размышлений
    double win_rate = 1.0, win_pitch = 0.96;  // скорость и высота голоса Windows (pitch < 1 = ниже, глубже)
    double silence = 1.2, threshold = 0.0;
    std::string wake;          // слово-активатор (например «флей»); пусто = отвечать на всё
    bool autostart = false;    // запуск вместе с Windows
    bool confirm = false;      // спрашивать подтверждение для опасных действий (по умолчанию нет)
    bool voice_fx = true;      // эффект «голос ИИ» поверх голоса Windows
    int fx_mode = 1;           // 0 = без эффектов, 1 = JARVIS (мягкий), 2 = робот (металл)
    std::string window_mode = "full";  // full = на весь экран, window = окно, mini = маленькое окно поверх всех
    bool openrouter = false;
    bool groq = false;
    bool windows_tts = false;  // озвучка встроенным голосом Windows
    bool pc = true;            // управление компьютером голосом (FLEY_PC_CONTROL=0 отключает)
    std::string tts_key, tts_host = "api.openai.com", tts_path = "/v1";  // отдельный ключ для нейро-озвучки (FLEY_TTS_API_KEY)
    bool tts_cloud = false;    // озвучка нейросетью OpenAI (голос как у JARVIS), иначе голос Windows
    std::string mic_device;    // часть названия микрофона (FLEY_MIC_DEVICE), пусто = микрофон по умолчанию
    bool greeting = true;      // приветствие JARVIS при запуске (FLEY_GREETING=0 отключает)
    bool denoise = false;       // шумоподавление записи (FLEY_DENOISE=0 отключает)
    double mic_gain = 2.0;     // цифровое усиление микрофона (для речи издалека); FLEY_MIC_GAIN
    std::string vision_model;  // модель, которая понимает картинки (зрение, FLEY_VISION_MODEL)
    bool screen_aware = false; // автоматически смотреть на экран перед каждым ответом (FLEY_SCREEN_AWARE=1)
    bool use_max_tokens = false;  // max_tokens вместо max_completion_tokens (все, кроме OpenAI и Groq)
    bool tls = true;              // false для локальных серверов (http://localhost:11434/v1 и т.п.)
    std::string provider;         // id провайдера (openai, groq, anthropic, gemini ...) или пусто = свой адрес
    bool stt_ok = true, stt_groq = false;  // есть ли распознавание речи; идёт ли оно через Groq
    std::string stt_key, stt_host, stt_path;  // отдельный ключ для распознавания (FLEY_STT_API_KEY); пусто = основной
    std::string stt_lang = "ru";  // язык распознавания речи; пусто = определять автоматически (FLEY_STT_LANG=auto)
    // --- добавлено: голосовой ввод для провайдеров без /audio/transcriptions
    std::string stt_endpoint = "/audio/transcriptions";  // xAI: /stt
    bool stt_chat = false;     // распознавание через чат-модель с аудио (Gemini)
    bool stt_plain = false;    // отправлять только model/language/file (xAI не любит лишние поля)
    bool stt_fallback = false; // речь распознаёт запасной ключ Groq (у основного провайдера нет распознавания)
};

inline void split_url(std::string url, std::string& host, std::string& path) {
    size_t p = url.find("://");
    if (p != std::string::npos) url = url.substr(p + 3);
    size_t s = url.find('/');
    if (s == std::string::npos) { host = url; path.clear(); }
    else { host = url.substr(0, s); path = url.substr(s); }
    while (!path.empty() && path.back() == '/') path.pop_back();
}

// Таблица провайдеров с OpenAI-совместимым API. Ключ определяется по префиксу; остальные - через FLEY_PROVIDER или FLEY_BASE_URL.
struct ProviderInfo { const char *id, *label, *base, *model, *vision, *stt, *tts; };
inline const std::vector<ProviderInfo>& provider_table() {
    static const std::vector<ProviderInfo> T = {
        {"openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", "gpt-4o-mini", "gpt-4o-mini-transcribe", "gpt-4o-mini-tts"},
        {"groq", "Groq", "https://api.groq.com/openai/v1", "openai/gpt-oss-120b", "qwen/qwen3.8-27b", "whisper-large-v3", "windows"},
        {"openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", "openai/gpt-4o-mini", "openai/whisper-large-v3", "openai/gpt-4o-mini-tts-2025-12-15"},
        {"anthropic", "Anthropic (Claude)", "https://api.anthropic.com/v1", "claude-haiku-5-5", "claude-haiku-5-5", "", "windows"},
        {"gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", "gemini-2.5-flash", "", "windows"},
        {"xai", "xAI (Grok)", "https://api.x.ai/v1", "grok-3-mini", "grok-2-vision-1212", "", "windows"},
        {"deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat", "", "", "windows"},
        {"mistral", "Mistral", "https://api.mistral.ai/v1", "mistral-small-latest", "mistral-small-latest", "voxtral-mini-latest", "windows"},
        {"together", "Together AI", "https://api.together.xyz/v1", "meta-llama/Llama-3.3-70B-Instruct-Turbo", "meta-llama/Llama-3.2-11B-Vision-Instruct-Turbo", "openai/whisper-large-v3", "windows"},
        {"cerebras", "Cerebras", "https://api.cerebras.ai/v1", "llama-3.3-70b", "", "", "windows"},
        {"perplexity", "Perplexity", "https://api.perplexity.ai", "sonar", "", "", "windows"},
        {"nvidia", "NVIDIA NIM", "https://integrate.api.nvidia.com/v1", "meta/llama-3.1-70b-instruct", "", "", "windows"},
        {"fireworks", "Fireworks", "https://api.fireworks.ai/inference/v1", "accounts/fireworks/models/llama-v3p3-70b-instruct", "", "", "windows"},
        {"huggingface", "Hugging Face", "https://router.huggingface.co/v1", "meta-llama/Llama-3.3-70B-Instruct", "", "", "windows"},
        {"sambanova", "SambaNova", "https://api.sambanova.ai/v1", "Meta-Llama-3.3-70B-Instruct", "", "", "windows"},
        {"ollama", "Ollama (локально)", "http://localhost:11434/v1", "llama3.1", "", "", "windows"},
        {"lmstudio", "LM Studio (локально)", "http://localhost:1234/v1", "local-model", "", "", "windows"},
        // --- добавлено: ещё провайдеры (выбираются по ключу или через FLEY_PROVIDER)
        {"cohere", "Cohere", "https://api.cohere.ai/compatibility/v1", "command-a-03-2025", "", "", "windows"},
        {"deepinfra", "DeepInfra", "https://api.deepinfra.com/v1/openai", "meta-llama/Llama-3.3-70B-Instruct-Turbo", "", "openai/whisper-large-v3-turbo", "windows"},
        {"moonshot", "Moonshot (Kimi)", "https://api.moonshot.ai/v1", "kimi-k2-0905-preview", "", "", "windows"},
        {"github", "GitHub Models", "https://models.github.ai/inference", "openai/gpt-4o-mini", "openai/gpt-4o-mini", "", "windows"},
        {"hyperbolic", "Hyperbolic", "https://api.hyperbolic.xyz/v1", "meta-llama/Llama-3.3-70B-Instruct", "", "", "windows"},
        {"novita", "Novita AI", "https://api.novita.ai/v3/openai", "meta-llama/llama-3.3-70b-instruct", "", "", "windows"},
    };
    return T;
}
inline const ProviderInfo* find_provider(const std::string& id) {
    for (const ProviderInfo& p : provider_table()) if (id == p.id) return &p;
    return nullptr;
}
// Провайдер по префиксу ключа; пусто, если не узнали (тогда FLEY_PROVIDER или FLEY_BASE_URL в .env)
inline std::string detect_provider(const std::string& k) {
    struct P { const char* pre; const char* id; };
    static const P T[] = {{"gsk_", "groq"}, {"sk-or-", "openrouter"}, {"sk-ant-", "anthropic"}, {"AIza", "gemini"}, {"xai-", "xai"},
                          {"csk-", "cerebras"}, {"pplx-", "perplexity"}, {"nvapi-", "nvidia"}, {"fw_", "fireworks"}, {"hf_", "huggingface"}, {"sk-", "openai"}};
    // добавлено: ключ DeepSeek выглядит как sk- + 32 символа hex (ключи OpenAI длиннее), иначе его принимали за OpenAI
    if (k.size() == 35 && k.compare(0, 3, "sk-") == 0 && k.find_first_not_of("0123456789abcdefABCDEF", 3) == std::string::npos) return "deepseek";
    // добавлено: GitHub Models (токены ghp_ / github_pat_ / gho_)
    if (k.compare(0, 4, "ghp_") == 0 || k.compare(0, 11, "github_pat_") == 0 || k.compare(0, 4, "gho_") == 0) return "github";
    for (const P& p : T) if (k.compare(0, std::strlen(p.pre), p.pre) == 0) return p.id;
    return "";
}
// Добавлено: ключи без префикса узнаём по форме (используется только если адрес сервера не задан вручную).
inline std::string guess_provider_by_shape(const std::string& k) {
    auto all = [&](const char* set) { return !k.empty() && k.find_first_not_of(set) == std::string::npos; };
    const char* hex = "0123456789abcdefABCDEF";
    const char* alnum = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (k.size() == 64 && all(hex)) return "together";
    if (k.size() == 36 && k[8] == '-' && k[13] == '-' && k[18] == '-' && k[23] == '-') return "sambanova";   // UUID
    if (k.size() == 32 && all(alnum)) return "mistral";
    if (k.size() == 40 && all(alnum)) return "cohere";
    return "";
}
inline std::string provider_label(const std::string& id) {
    const ProviderInfo* p = find_provider(id);
    return p ? p->label : "";
}

inline Settings make_settings(const std::map<std::string, std::string>& env, const std::string& default_key = "") {
    auto get = [&](const char* k, const std::string& def) {
        auto it = env.find(k);
        return (it != env.end() && !it->second.empty()) ? it->second : def;
    };
    Settings s;
    s.key = get("OPENAI_API_KEY", get("OPENROUTER_API_KEY", get("GROQ_API_KEY", default_key)));
    std::string pid = to_lower_ascii(get("FLEY_PROVIDER", ""));
    const std::string customUrl = get("FLEY_BASE_URL", "");
    if (pid.empty()) pid = detect_provider(s.key);
    if (pid.empty() && customUrl.empty()) pid = guess_provider_by_shape(s.key);   // добавлено
    if (pid.empty() && !customUrl.empty()) {   // адрес задан вручную: пробуем узнать провайдера по хосту
        std::string h, pth;
        split_url(customUrl, h, pth);
        for (const ProviderInfo& pi : provider_table()) {
            std::string ph, pp;
            split_url(pi.base, ph, pp);
            if (h == ph) { pid = pi.id; break; }
        }
    }
    const ProviderInfo* pi = find_provider(pid);
    if (!pi && customUrl.empty()) pi = find_provider("openai");   // неизвестный ключ без адреса: как раньше, OpenAI
    s.provider = pi ? pi->id : "custom";
    if (s.key.empty() && pi && std::string(pi->id) == "ollama") s.key = "ollama";
    if (s.key.empty() && pi && std::string(pi->id) == "lmstudio") s.key = "lm-studio";
    s.groq = s.provider == "groq";
    s.openrouter = s.provider == "openrouter";
    s.use_max_tokens = !(s.provider == "openai" || s.provider == "groq");
    std::string base = pi ? pi->base : customUrl;
    std::string model = pi ? pi->model : "gpt-4o-mini";
    std::string stt = pi ? pi->stt : "";
    std::string tts = pi && pi->tts[0] ? pi->tts : "windows";
    std::string url = customUrl.empty() ? base : customUrl;
    s.tls = url.compare(0, 7, "http://") != 0;
    split_url(url, s.host, s.base_path);
    s.model = get("FLEY_MODEL", model);
    s.vision_model = get("FLEY_VISION_MODEL", pi && pi->vision[0] ? pi->vision : s.model);
    {   // распознавание речи: у провайдера своё или отдельный ключ (FLEY_STT_API_KEY, например бесплатный Groq)
        s.stt_key = get("FLEY_STT_API_KEY", "");
        if (!s.stt_key.empty()) {
            std::string sp = detect_provider(s.stt_key);
            const ProviderInfo* si = find_provider(get("FLEY_STT_PROVIDER", sp.empty() ? "openai" : sp));
            if (!si) si = find_provider("openai");
            split_url(get("FLEY_STT_BASE_URL", si->base), s.stt_host, s.stt_path);
            stt = si->stt[0] ? si->stt : "whisper-1";
            s.stt_groq = std::string(si->id) == "groq";
            s.stt_ok = true;
        } else {
            s.stt_groq = s.groq;
            s.stt_ok = !stt.empty() || !get("FLEY_STT_MODEL", "").empty();
        }
    }
    {   // --- добавлено: голосовой ввод для провайдеров, у которых нет /audio/transcriptions
        if (s.stt_key.empty() && get("FLEY_STT_MODEL", "").empty()) {
            if (s.provider == "gemini") {            // аудио понимает сама модель Gemini (тот же ключ)
                s.stt_chat = true; s.stt_ok = true; stt = "gemini-2.5-flash";
            } else if (s.provider == "xai") {        // xAI: отдельный адрес /v1/stt
                s.stt_endpoint = "/stt"; s.stt_plain = true; s.stt_ok = true; stt = "grok-voice-transcribe-2.0";
            } else if (s.provider == "fireworks") {  // Whisper на отдельном хосте Fireworks, тот же ключ
                s.stt_key = s.key; s.stt_host = "audio-prod.api.fireworks.ai"; s.stt_path = "/v1"; s.stt_ok = true; stt = "whisper-v3";
            }
        }
        std::string fb = to_lower_ascii(get("FLEY_STT_FALLBACK", "1"));
        // Anthropic, Cerebras, Perplexity, NVIDIA, Hugging Face, DeepSeek и др. не умеют распознавать речь:
        // тогда речь распознаёт Groq (ключ по умолчанию), а отвечает ваш провайдер. Отключить: FLEY_STT_FALLBACK=0
        if (!s.stt_ok && s.stt_key.empty() && !(fb == "0" || fb == "false" || fb == "no" || fb == "off") &&
            detect_provider(default_key) == "groq") {
            s.stt_key = default_key;
            split_url(find_provider("groq")->base, s.stt_host, s.stt_path);
            stt = find_provider("groq")->stt;
            s.stt_groq = true; s.stt_ok = true; s.stt_fallback = true;
        }
    }
    {
        std::string sa = to_lower_ascii(get("FLEY_SCREEN_AWARE", "0"));
        s.screen_aware = (sa == "1" || sa == "true" || sa == "yes" || sa == "on");
    }
    s.stt = get("FLEY_STT_MODEL", stt.empty() ? "whisper-1" : stt);
    s.tts = get("FLEY_TTS_MODEL", tts);
    s.windows_tts = to_lower_ascii(s.tts) == "windows";
    s.tts_key = get("FLEY_TTS_API_KEY", "");
    s.tts_cloud = !s.tts_key.empty();
    if (s.tts_cloud) {
        split_url(get("FLEY_TTS_BASE_URL", "https://api.openai.com/v1"), s.tts_host, s.tts_path);
        s.tts = get("FLEY_TTS_MODEL", "gpt-4o-mini-tts");
        s.windows_tts = to_lower_ascii(s.tts) == "windows";
        s.tts_cloud = !s.windows_tts;
    }
    s.voice = get("FLEY_VOICE", s.tts_cloud ? "ash" : "onyx");
    {
        std::string pc = to_lower_ascii(get("FLEY_PC_CONTROL", "1"));
        s.pc = !(pc == "0" || pc == "false" || pc == "no" || pc == "off");
    }
    {   // 0.9 с (старое значение) обрывало фразы на паузах между словами - заменяем на 1.2 с
        std::string sv = get("FLEY_SILENCE_SECONDS", "1.2");
        if (sv == "0.9") sv = "1.2";
        s.silence = std::strtod(sv.c_str(), nullptr);
        if (s.silence < 0.4 || s.silence > 5.0) s.silence = 1.2;
    }
    {
        std::string c = to_lower_ascii(get("FLEY_CONFIRM", "0"));
        s.confirm = (c == "1" || c == "true" || c == "yes" || c == "on");
        std::string f = to_lower_ascii(get("FLEY_VOICE_FX", "1"));
        s.voice_fx = !(f == "0" || f == "false" || f == "no" || f == "off");
        s.fx_mode = !s.voice_fx ? 0 : (f == "2" || f == "robot" || f == "робот") ? 2 : 1;
    }
    {
        std::string wm = to_lower_ascii(get("FLEY_WINDOW_MODE", "full"));
        s.window_mode = (wm == "window" || wm == "mini") ? wm : "full";
    }
    s.wake = get("FLEY_WAKE", "");
    {
        std::string a = to_lower_ascii(get("FLEY_AUTOSTART", "0"));
        s.autostart = (a == "1" || a == "true" || a == "yes" || a == "on");
    }
    s.win_voice = get("FLEY_WINDOWS_VOICE", "");
    s.call_me = get("FLEY_CALL_ME", "");
    s.effort = to_lower_ascii(get("FLEY_REASONING", "low"));
    if (s.effort != "low" && s.effort != "medium" && s.effort != "high") s.effort = "low";
    {
        // старые значения по умолчанию (0.85 / 1.05 звучали глухо и «роботно») автоматически заменяем на новые
        std::string rt = get("FLEY_VOICE_RATE", "1.0"), pt = get("FLEY_VOICE_PITCH", "0.96");
        if (rt == "1.05") rt = "1.0";
        if (pt == "0.85") pt = "0.96";
        s.win_rate = std::strtod(rt.c_str(), nullptr);
        if (s.win_rate < 0.5 || s.win_rate > 2.5) s.win_rate = 1.0;
        s.win_pitch = std::strtod(pt.c_str(), nullptr);
        if (s.win_pitch < 0.5 || s.win_pitch > 1.5) s.win_pitch = 0.96;
    }
    {
        std::string d = to_lower_ascii(get("FLEY_DENOISE", "0"));
        s.denoise = (d == "1" || d == "true" || d == "yes" || d == "on");
    }
    {
        std::string g = to_lower_ascii(get("FLEY_GREETING", "1"));
        s.greeting = !(g == "0" || g == "false" || g == "no" || g == "off");
    }
    s.mic_device = get("FLEY_MIC_DEVICE", "");
    s.mic_gain = std::strtod(get("FLEY_MIC_GAIN", "2").c_str(), nullptr);
    if (s.mic_gain < 1.0 || s.mic_gain > 20.0) s.mic_gain = 2.0;
    {
        std::string l = to_lower_ascii(get("FLEY_STT_LANG", "ru"));
        s.stt_lang = (l == "auto" || l == "none" || l == "0") ? "" : l.substr(0, 5);
    }
    s.threshold = std::strtod(get("FLEY_VOICE_THRESHOLD", "0").c_str(), nullptr);
    return s;
}

// ---------------------------------------------------------------- аудио
inline void put16(std::string& s, uint32_t v) { for (int i = 0; i < 2; ++i) s.push_back((char)((v >> (8 * i)) & 0xFF)); }
inline void put32(std::string& s, uint32_t v) { for (int i = 0; i < 4; ++i) s.push_back((char)((v >> (8 * i)) & 0xFF)); }

inline std::string make_wav(const std::string& pcm, int rate, int channels = 1) {
    std::string w;
    w.reserve(44 + pcm.size());
    w += "RIFF"; put32(w, (uint32_t)(36 + pcm.size()));
    w += "WAVEfmt "; put32(w, 16); put16(w, 1); put16(w, (uint32_t)channels);
    put32(w, (uint32_t)rate); put32(w, (uint32_t)(rate * channels * 2)); put16(w, (uint32_t)(channels * 2)); put16(w, 16);
    w += "data"; put32(w, (uint32_t)pcm.size());
    w += pcm;
    return w;
}

inline int parse_rate(const std::string& content_type, int def = 24000) {
    size_t p = content_type.find("rate=");
    if (p == std::string::npos) return def;
    int r = std::atoi(content_type.c_str() + p + 5);
    return (r >= 8000 && r <= 96000) ? r : def;
}

inline double rms16(const short* d, size_t n) {
    if (!n) return 0;
    double acc = 0;
    for (size_t i = 0; i < n; ++i) acc += (double)d[i] * d[i];
    return std::sqrt(acc / (double)n);
}

// ---------------------------------------------------------------- multipart
struct Multipart {
    std::string boundary = "----FLEYBoundary7MA4YWxkTrZu0gW";
    std::string body;
    void field(const std::string& name, const std::string& value) {
        body += "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n";
    }
    void file(const std::string& name, const std::string& filename, const std::string& ctype, const std::string& data) {
        body += "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"; filename=\"" + filename +
                "\"\r\nContent-Type: " + ctype + "\r\n\r\n" + data + "\r\n";
    }
    std::string finish() const { return body + "--" + boundary + "--\r\n"; }
    std::string content_type() const { return "multipart/form-data; boundary=" + boundary; }
};

// ---------------------------------------------------------------- VAD (авто-стоп по тишине)
// Блоки по 50 мс. Первые 10 блоков (0.5 c) - калибровка шума.
class Vad {
public:
    enum Result { Continue, Done, NoSpeech };
    Vad(double silence_s, double fixed_threshold) : silence_(silence_s), fixed_(fixed_threshold) {}

    Result feed(double rms) {
        size_t idx = n_++;
        if (idx < kCalib) {
            noise_.push_back(rms);
            if (idx == kCalib - 1) {
                std::vector<double> v = noise_;
                std::sort(v.begin(), v.end());
                double p90 = v[(size_t)(0.9 * (double)(v.size() - 1))];
                thr_ = fixed_ > 0 ? fixed_ : std::min(std::max(300.0, p90 * 3.0), 2000.0);
            }
            return Continue;
        }
        if (rms > thr_) { speech_ = true; last_voice_ = (long)idx; }
        double t = (double)idx * kBlock;
        if (speech_ && quiet_s() >= silence_) return Done;
        if (!speech_ && t - kCalib * kBlock > kNoSpeechTimeout) return NoSpeech;
        if (t > kMaxRecord) return speech_ ? Done : NoSpeech;
        return Continue;
    }
    bool speech() const { return speech_; }
    double quiet_s() const { return speech_ ? (double)((long)n_ - 1 - last_voice_) * kBlock : 0.0; }
    int seconds_left() const { return (int)std::ceil(silence_ - quiet_s()); }
    // сколько блоков оставить в записи: до последнего голоса + 0.5 c хвоста
    size_t keep_blocks() const { return std::min(n_, (size_t)(last_voice_ + 1 + 10)); }

    static constexpr double kBlock = 0.05;
    static constexpr double kNoSpeechTimeout = 12.0;
    static constexpr double kMaxRecord = 90.0;
    static constexpr size_t kCalib = 10;

private:
    double silence_, fixed_, thr_ = 300.0;
    size_t n_ = 0;
    long last_voice_ = -1;
    bool speech_ = false;
    std::vector<double> noise_;
};


// ---------------------------------------------------------------- непрерывный детектор речи
// Микрофон слушает постоянно (как телефонный звонок). Блоки по 50 мс.
// Порог адаптивный: считается от уровня фонового шума, который отслеживается всё время.
// Высказывание начинается после 2 громких блоков подряд (с предзаписью 0.4 с) и заканчивается
// через silence_s секунд тишины. Короткие щелчки (меньше ~0.3 с речи) отбрасываются.
class Endpointer {
public:
    Endpointer(double silence_s, double fixed_threshold, double init_floor = 150.0)
        : silence_(silence_s), fixed_(fixed_threshold), floor_(init_floor) {}

    // true, если собрано целое высказывание (его можно забрать через take())
    bool feed(const short* d, size_t n) {
        if (!n) return false;
        block_ = n;
        double rms = rms16(d, n);
        double thr = threshold();
        bool voiced = rms > (in_speech_ ? thr * 0.6 : thr);  // гистерезис: тихие слоги и окончания слов не обрывают фразу
        if (!voiced && !in_speech_) floor_ = rms < floor_ ? floor_ * 0.6 + rms * 0.4 : floor_ * 0.98 + rms * 0.02;

        if (!in_speech_) {
            pre_.emplace_back(d, d + n);
            while (pre_.size() > kPre) pre_.pop_front();
            run_ = voiced ? run_ + 1 : 0;
            if (run_ >= 2) {
                for (auto& b : pre_) utt_.insert(utt_.end(), b.begin(), b.end());
                pre_.clear();
                in_speech_ = true;
                quiet_ = 0;
                blocks_ = 0;
                voiced_blocks_ = run_;
            }
            return false;
        }
        utt_.insert(utt_.end(), d, d + n);
        ++blocks_;
        if (voiced) { quiet_ = 0; ++voiced_blocks_; } else ++quiet_;
        bool end = (double)quiet_ * kBlock >= silence_ || (double)blocks_ * kBlock > kMaxUtt;
        if (!end) return false;
        in_speech_ = false;
        run_ = 0;
        if (voiced_blocks_ < kMinVoiced) { utt_.clear(); return false; }  // щелчок / шум
        // обрезаем лишнюю тишину в конце, оставляя 0.3 с
        size_t keep_quiet = 10;
        if (quiet_ > keep_quiet) {
            size_t cut = (quiet_ - keep_quiet) * block_;
            if (cut < utt_.size()) utt_.resize(utt_.size() - cut);
        }
        return true;
    }
    std::vector<short> take() { std::vector<short> r; r.swap(utt_); return r; }
    bool in_speech() const { return in_speech_; }
    double floor() const { return floor_; }
    double threshold() const {
        return fixed_ > 0 ? fixed_ : std::min(std::max(200.0, floor_ * 3.0), 3500.0);
    }

    static constexpr double kBlock = 0.05;
    static constexpr double kMaxUtt = 60.0;
    static constexpr size_t kPre = 12;
    static constexpr size_t kMinVoiced = 8;

private:
    double silence_, fixed_, floor_;
    size_t block_ = 800, run_ = 0, quiet_ = 0, blocks_ = 0, voiced_blocks_ = 0;
    bool in_speech_ = false;
    std::deque<std::vector<short>> pre_;
    std::vector<short> utt_;
};

// Нижний регистр для ASCII и кириллицы (UTF-8)
inline std::string lower_utf8(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        unsigned char c = (unsigned char)s[i];
        if (c == 0xD0 && i + 1 < s.size()) {
            unsigned char d = (unsigned char)s[i + 1];
            if (d >= 0x90 && d <= 0x9F) { o += (char)0xD0; o += (char)(d + 0x20); ++i; continue; }
            if (d >= 0xA0 && d <= 0xAF) { o += (char)0xD1; o += (char)(d - 0x20); ++i; continue; }
            if (d == 0x81) { o += (char)0xD1; o += (char)0x91; ++i; continue; }
            o += (char)c; continue;
        }
        o += (c < 0x80) ? (char)std::tolower(c) : (char)c;
    }
    return o;
}
inline bool has_wake_word(const std::string& text, const std::string& wake) {
    if (wake.empty()) return true;
    return lower_utf8(text).find(lower_utf8(wake)) != std::string::npos;
}

// Whisper на шуме/тишине любит «галлюцинировать» одни и те же фразы - такие ответы игнорируем
// Улучшение записи микрофона перед распознаванием: убираем постоянную составляющую и гул,
// подтягиваем тихую речь до нормального уровня (автоусиление), чтобы Whisper лучше слышал.
// ---------------------------------------------------------------- шумоподавление (спектральное вычитание)
// Для речи издалека: профиль шума берётся из самых тихих кадров самой записи и вычитается из спектра.
inline void fft_inplace(std::vector<std::complex<double>>& a, bool inv) {
    size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1) {
        double ang = 2.0 * 3.14159265358979323846 / (double)len * (inv ? 1 : -1);
        std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<double> w(1);
            for (size_t j = 0; j < len / 2; ++j) {
                auto u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wl;
            }
        }
    }
    if (inv) for (auto& x : a) x /= (double)n;
}

inline void pcm_denoise(std::vector<short>& pcm, double strength = 1.6) {
    const size_t N = 512, H = 256;
    if (pcm.size() < N * 6) return;
    size_t frames = (pcm.size() - N) / H + 1;
    std::vector<double> win(N);
    for (size_t i = 0; i < N; ++i) win[i] = std::sin(3.14159265358979323846 * ((double)i + 0.5) / (double)N);  // sqrt-hann
    std::vector<std::vector<std::complex<double>>> spec(frames, std::vector<std::complex<double>>(N));
    std::vector<double> energy(frames);
    for (size_t f = 0; f < frames; ++f) {
        double e = 0;
        for (size_t i = 0; i < N; ++i) {
            double v = (double)pcm[f * H + i] * win[i];
            spec[f][i] = v;
            e += v * v;
        }
        energy[f] = e;
        fft_inplace(spec[f], false);
    }
    std::vector<size_t> idx(frames);
    for (size_t i = 0; i < frames; ++i) idx[i] = i;
    std::sort(idx.begin(), idx.end(), [&](size_t a, size_t b) { return energy[a] < energy[b]; });
    size_t nq = std::max<size_t>(3, frames / 6);
    std::vector<double> noise(N / 2 + 1, 0.0);
    for (size_t k = 0; k < nq; ++k)
        for (size_t b = 0; b <= N / 2; ++b) noise[b] += std::abs(spec[idx[k]][b]) / (double)nq;
    std::vector<double> out(pcm.size() + N, 0.0);
    for (size_t f = 0; f < frames; ++f) {
        for (size_t b = 0; b <= N / 2; ++b) {
            double mag = std::abs(spec[f][b]);
            double clean = std::max(mag - strength * noise[b], 0.12 * mag);  // пол 12%: без «металлических» артефактов
            double g = mag > 1e-9 ? clean / mag : 1.0;
            spec[f][b] *= g;
            if (b > 0 && b < N / 2) spec[f][N - b] = std::conj(spec[f][b]);
        }
        fft_inplace(spec[f], true);
        for (size_t i = 0; i < N; ++i) out[f * H + i] += spec[f][i].real() * win[i];
    }
    for (size_t i = 0; i < pcm.size() && i < frames * H + N - H; ++i)
        pcm[i] = (short)std::lround(std::max(-32767.0, std::min(32767.0, out[i])));
}

// Автоподстройка усиления: если речь в записи тихая (говорят издалека), в следующий раз усиливаем сильнее.
inline double agc_next(double gain, double utt_rms, double base, double max_gain, double target = 2200.0) {
    if (utt_rms < 50.0) return gain;
    double want = gain * target / utt_rms;
    double next = gain * std::pow(want / gain, 0.5);  // плавно, половинным шагом
    return std::max(base, std::min(max_gain, next));
}

// Цифровое усиление с мягким ограничением: тихая далёкая речь становится слышной, громкая не хрипит.
inline void pcm_gain(short* d, size_t n, double gain) {
    if (gain <= 1.001) return;
    for (size_t i = 0; i < n; ++i) {
        double v = (double)d[i] * gain, a = std::fabs(v);
        if (a > 22000.0) a = 22000.0 + 10700.0 * std::tanh((a - 22000.0) / 10700.0);
        d[i] = (short)std::lround(v < 0 ? -a : a);
    }
}

inline void pcm_enhance(std::vector<short>& pcm, int rate = 16000) {
    if (pcm.size() < 200) return;
    const double kPi = 3.14159265358979323846;
    const float a = (float)std::exp(-2.0 * kPi * 100.0 / (double)rate);
    std::vector<float> f(pcm.size());
    float hp = 0, px = 0, peak = 0;
    for (size_t i = 0; i < pcm.size(); ++i) {
        float v = (float)pcm[i] / 32768.0f;
        hp = a * (hp + v - px);
        px = v;
        f[i] = hp;
    }
    // пик считаем по 99.5-му перцентилю, чтобы одиночный щелчок не «глушил» усиление
    std::vector<float> m(f.size());
    for (size_t i = 0; i < f.size(); ++i) m[i] = std::fabs(f[i]);
    size_t k = (size_t)((double)m.size() * 0.995);
    std::nth_element(m.begin(), m.begin() + (long)std::min(k, m.size() - 1), m.end());
    peak = m[std::min(k, m.size() - 1)];
    float gain = peak > 0.003f ? std::min(30.0f, 0.60f / peak) : 1.0f;
    if (gain < 1.0f) gain = 1.0f;  // громкую запись не трогаем
    for (size_t i = 0; i < f.size(); ++i) {
        float v = std::max(-1.0f, std::min(1.0f, f[i] * gain));
        pcm[i] = (short)std::lround(v * 32767.0f);
    }
}

// Глубина размышлений: короткие команды - быстро, вопросы и сложные просьбы - вдумчивее.
inline std::string choose_effort(const std::string& text, const std::string& base) {
    std::string t = lower_utf8(trim(text));
    if (base == "high") return base;
    static const char* hard[] = {"почему", "как работает", "объясни", "посчитай", "сколько будет", "реши", "задач", "сравни",
                                 "расскажи", "что такое", "в чём разница", "напиши код", "программ", "why ", "explain",
                                 "how does", "calculate", "compare", "что лучше", "посоветуй", "придумай", "переведи"};
    for (const char* h : hard)
        if (t.find(h) != std::string::npos) return "medium";
    if (t.size() > 140) return "medium";
    return base;
}

 // Ответ Whisper (verbose_json): тихий шум и невнятная речь дают низкую уверенность. Такие «фразы» отбрасываем.
inline bool stt_low_confidence(const Json& j) {
    const Json& seg = j["segments"];
    if (seg.t != Json::Arr || seg.a.empty()) return false;
    size_t bad = 0;
    for (const Json& s : seg.a) {
        double nsp = s["no_speech_prob"].n, lp = s["avg_logprob"].n, cr = s["compression_ratio"].n;
        if ((nsp > 0.8 && lp < -1.0) || lp < -2.0 || cr > 3.0) ++bad;  // мягкий порог: отбрасываем только явный шум
    }
    return bad == seg.a.size();
}

inline bool is_noise_transcript(const std::string& text) {
    std::string t = to_lower_ascii(trim(text));
    if (t.size() < 2) return true;
    static const char* junk[] = {"субтитры", "продолжение следует", "спасибо за просмотр", "thanks for watching",
                                 "thank you for watching", "subtitles by", "редактор субтитров", "корректор",
                                 "подписывайтесь на канал", "dimatorzok", "amara.org", "до новых встреч", "всем пока", "переводчик", "озвучивание", "смотрите продолжение"};
    for (const char* j : junk)
        if (t.find(j) != std::string::npos && t.size() < 80) return true;
    bool letters = false;
    for (unsigned char c : t) if (isalnum(c) || c >= 0x80) { letters = true; break; }
    return !letters;
}

// ---------------------------------------------------------------- «голос ИИ»: обработка WAV
// Лёгкий металлический призвук (гребенчатый фильтр), едва заметная кольцевая модуляция и короткое
// эхо, как у компьютерного ассистента. Принимает WAV PCM16 (моно/стерео), возвращает новый WAV.
inline uint32_t rd_le(const std::string& s, size_t o, int bytes) {
    uint32_t v = 0;
    for (int i = 0; i < bytes && o + (size_t)i < s.size(); ++i) v |= (uint32_t)(unsigned char)s[o + (size_t)i] << (8 * i);
    return v;
}
inline bool wav_apply_fx(std::string& wav, int mode = 1) {
    if (mode <= 0) return false;
    if (wav.size() < 44 || wav.compare(0, 4, "RIFF") != 0 || wav.compare(8, 4, "WAVE") != 0) return false;
    size_t p = 12, data_off = 0, data_len = 0;
    int fmt = 0, ch = 0, bits = 0, rate = 0;
    while (p + 8 <= wav.size()) {
        std::string id = wav.substr(p, 4);
        size_t len = rd_le(wav, p + 4, 4);
        if (id == "fmt " && p + 8 + 16 <= wav.size()) {
            fmt = (int)rd_le(wav, p + 8, 2);
            ch = (int)rd_le(wav, p + 10, 2);
            rate = (int)rd_le(wav, p + 12, 4);
            bits = (int)rd_le(wav, p + 22, 2);
        } else if (id == "data") {
            data_off = p + 8;
            data_len = std::min(len, wav.size() - data_off);
            break;
        }
        p += 8 + len + (len & 1);
    }
    if (fmt != 1 || bits != 16 || ch < 1 || ch > 2 || rate < 8000 || rate > 96000 || !data_off) return false;
    size_t frames = data_len / (size_t)(2 * ch);
    if (frames < 100) return false;
    size_t tail = (size_t)(rate * (mode == 1 ? 0.5 : 0.35));
    size_t total = frames + tail;
    size_t d1 = (size_t)(rate * 0.0065), d2 = (size_t)(rate * 0.0123), d3 = (size_t)(rate * 0.062);
    const double kPi = 3.14159265358979323846;
    std::vector<std::vector<float>> out((size_t)ch, std::vector<float>(total, 0.0f));
    for (int c = 0; c < ch; ++c) {
        std::vector<float> x(total, 0.0f), y(total, 0.0f);
        for (size_t i = 0; i < frames; ++i) {
            short v = (short)rd_le(wav, data_off + (i * (size_t)ch + (size_t)c) * 2, 2);
            x[i] = (float)v / 32768.0f;
        }
        if (mode == 2) {  // робот: гребенчатый фильтр + кольцевая модуляция + эхо
            for (size_t i = 0; i < total; ++i) {
                float v = x[i];
                if (i >= d1) v += 0.30f * x[i - d1];
                if (i >= d2) v += 0.16f * x[i - d2];
                double ring = std::sin(2.0 * kPi * 85.0 * (double)i / (double)rate);
                y[i] = (float)(v * (1.0 - 0.14) + v * ring * 0.14);
            }
            std::vector<float> e(total, 0.0f);
            for (size_t i = 0; i < total; ++i) {
                e[i] = y[i] + (i >= d3 ? 0.32f * e[i - d3] : 0.0f);
                out[(size_t)c][i] = 0.80f * y[i] + 0.30f * e[i];
            }
        } else {  // 1 = «живой JARVIS»: естественный тёплый голос без металла и эха
            const float a_hp = (float)std::exp(-2.0 * kPi * 75.0 / (double)rate);
            const float k180 = (float)(1.0 - std::exp(-2.0 * kPi * 180.0 / (double)rate));
            const float k4k = (float)(1.0 - std::exp(-2.0 * kPi * 4200.0 / (double)rate));
            float hp = 0, px = 0, lo = 0, hi = 0, env = 0;
            std::vector<float> w(total, 0.0f);
            for (size_t i = 0; i < total; ++i) {
                float v = x[i];
                hp = a_hp * (hp + v - px);
                px = v;
                v = hp;
                lo += k180 * (v - lo);
                hi += k4k * (v - hi);
                float t = v + 0.20f * lo + 0.12f * (v - hi);  // чуть больше тепла и разборчивости
                // мягкий компрессор: ровная громкость, как у живого диктора
                float a = std::fabs(t);
                env += (a > env ? 0.02f : 0.0004f) * (a - env);
                float g = env > 0.25f ? 0.25f / env * 0.5f + 0.5f : 1.0f;
                w[i] = t * g;
            }
            size_t k1 = (size_t)(rate * 0.032);
            for (size_t i = 0; i < total; ++i) {  // едва слышная «комната»
                float v = w[i];
                if (i >= k1) v += 0.07f * w[i - k1];
                out[(size_t)c][i] = v;
            }
        }
    }
    float peak = 0.0f;
    for (auto& v : out) for (float f : v) peak = std::max(peak, std::fabs(f));
    float gain = peak > 0.0001f ? std::min(3.0f, 0.89f / peak) : 1.0f;
    std::string pcm;
    pcm.reserve(total * (size_t)ch * 2);
    for (size_t i = 0; i < total; ++i)
        for (int c = 0; c < ch; ++c) {
            float f = out[(size_t)c][i] * gain;
            f = std::max(-1.0f, std::min(1.0f, f));
            put16(pcm, (uint32_t)(uint16_t)(short)std::lround(f * 32767.0f));
        }
    wav = make_wav(pcm, rate, ch);
    return true;
}

// Делит ответ на 2 части (первое предложение + остальное), чтобы начать говорить раньше
inline std::vector<std::string> split_speech(const std::string& text) {
    std::vector<std::string> r;
    std::string t = trim(text);
    if (t.size() < 160) { r.push_back(t); return r; }
    size_t cut = std::string::npos;
    for (size_t i = 24; i < t.size() && i < 260; ++i) {
        char c = t[i];
        if ((c == '.' || c == '!' || c == '?') && i + 1 < t.size() && t[i + 1] == ' ') { cut = i + 1; break; }
    }
    if (cut == std::string::npos) { r.push_back(t); return r; }
    r.push_back(trim(t.substr(0, cut)));
    std::string rest = trim(t.substr(cut));
    if (!rest.empty()) r.push_back(rest);
    return r;
}

// ---------------------------------------------------------------- ошибки API по-русски
inline std::string error_message(const std::string& body) {
    Json j;
    if (!json_parse(body, j)) return trim(body.substr(0, 200));
    const Json& e = j["error"];
    if (e.t == Json::Str) return e.s;
    if (e.is_obj()) {
        std::string m = e["message"].str();
        if (!m.empty()) return m;
    }
    std::string m = j["message"].str();
    return m;
}

inline std::string explain_error(int status, const std::string& body) {
    std::string low = to_lower_ascii(body);
    std::string msg = error_message(body);
    bool money = low.find("quota") != std::string::npos || low.find("billing") != std::string::npos ||
                 low.find("insufficient") != std::string::npos || low.find("credits") != std::string::npos;
    if (status == 429 && low.find("per day") != std::string::npos)
        return "Дневной лимит Groq исчерпан (обновится в течение суток). Можно сменить ключ в настройках.";
    switch (status) {
        case 401:
            return "Ключ не подходит или не задан. Создайте бесплатный ключ на console.groq.com/keys (подойдёт ключ любого провайдера: Groq, OpenAI, OpenRouter), нажмите шестерёнку вверху и вставьте его.";
        case 402:
            return "Недостаточно кредитов. Пополните баланс: openrouter.ai/credits";
        case 403:
            return "Нет доступа к модели или региону (попробуйте VPN). Проверьте названия моделей в .env. " + msg;
        case 404:
            return "Модель не найдена. Проверьте названия моделей в .env. " + msg;
        case 429:
            if (money)
                return "Ошибка 429: на аккаунте закончились деньги или лимит. Пополните баланс "
                       "(OpenRouter: openrouter.ai/credits, OpenAI: platform.openai.com - Billing).";
            return "Ошибка 429: слишком много запросов. Подождите минуту и повторите.";
        case 400:
            return "Запрос отклонён: " + msg;
        default:
            break;
    }
    if (status >= 500) return "Сервер временно недоступен (" + std::to_string(status) + "). Попробуйте ещё раз. " + msg;
    return "Ошибка HTTP " + std::to_string(status) + ": " + msg;
}


// ------------------------------------------------------------------ действия на ПК (разбор тегов)
struct Action {
    std::string type;               // open_app, youtube, run ...
    std::vector<std::string> args;  // аргументы
};

// Вырезает теги [[ACTION: тип | арг | арг]] из ответа модели. Возвращает текст без тегов.
inline std::string extract_actions(const std::string& in, std::vector<Action>& out) {
    std::string text;
    size_t pos = 0;
    while (true) {
        size_t a = in.find("[[", pos);
        if (a == std::string::npos) { text += in.substr(pos); break; }
        size_t b = in.find("]]", a + 2);
        if (b == std::string::npos) { text += in.substr(pos); break; }
        std::string inner = trim(in.substr(a + 2, b - a - 2));
        if (inner.size() >= 7 && to_lower_ascii(inner.substr(0, 7)) == "action:") {
            text += in.substr(pos, a - pos);
            std::string body = inner.substr(7);
            Action act;
            size_t st = 0;
            bool first = true;
            while (true) {
                size_t bar = body.find('|', st);
                std::string part = trim(body.substr(st, bar == std::string::npos ? std::string::npos : bar - st));
                if (first) { act.type = to_lower_ascii(part); first = false; }
                else act.args.push_back(part);
                if (bar == std::string::npos) break;
                st = bar + 1;
            }
            if (!act.type.empty()) out.push_back(act);
        } else {
            text += in.substr(pos, b + 2 - pos);
        }
        pos = b + 2;
    }
    return trim(text);
}

// Процентное кодирование (UTF-8) для URL
inline std::string url_encode(const std::string& s) {
    static const char* hex = "0123456789ABCDEF";
    std::string o;
    for (unsigned char c : s) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
        else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
    }
    return o;
}

// Разрешаем только обычные http/https-ссылки без пробелов и кавычек
inline bool is_http_url(const std::string& u) {
    std::string l = to_lower_ascii(u);
    if (l.compare(0, 8, "https://") != 0 && l.compare(0, 7, "http://") != 0) return false;
    for (unsigned char c : u) if (c <= 32 || c == '"' || c == '<' || c == '>' || c == '^' || c == '|') return false;
    return u.size() < 2000;
}

// Действия, требующие подтверждения пользователя в окне
inline bool is_dangerous_action(const std::string& type) {
    return type == "run" || type == "delete" || type == "close_app" || type == "power";
}

// Имя процесса для taskkill: только безопасные символы, .exe в конце
inline std::string safe_process_name(std::string n) {
    n = trim(n);
    std::string o;
    for (unsigned char c : n) if (isalnum(c) || c == '.' || c == '_' || c == '-') o += (char)c;
    if (o.empty()) return "";
    std::string l = to_lower_ascii(o);
    if (l.size() < 4 || l.compare(l.size() - 4, 4, ".exe") != 0) o += ".exe";
    return o;
}

// Пути, которые нельзя удалять ни при каких обстоятельствах (сравнение в нижнем регистре, слэши вида \)
inline bool is_protected_path(std::string p) {
    p = to_lower_ascii(trim(p));
    for (char& c : p) if (c == '/') c = '\\';
    while (p.size() > 3 && p.back() == '\\') p.pop_back();
    if (p.size() <= 3) return true;  // корень диска
    static const char* roots[] = {"c:\\windows", "c:\\program files", "c:\\program files (x86)", "c:\\programdata", "c:\\users"};
    for (const char* r : roots) {
        std::string rs = r;
        if (p == rs) return true;
        if (rs == "c:\\windows" && p.compare(0, rs.size() + 1, rs + "\\") == 0) return true;
        if (rs.compare(0, 10, "c:\\program") == 0 && p.compare(0, rs.size() + 1, rs + "\\") == 0) return true;
    }
    return false;
}


// ---------------------------------------------------------------- запись значения в .env (сохраняет остальные строки)
inline std::string set_env_value(const std::string& text, const std::string& key, const std::string& value, bool create = true) {
    std::vector<std::string> lines;
    size_t p = 0;
    while (p <= text.size()) {
        size_t e = text.find('\n', p);
        std::string ln = text.substr(p, e == std::string::npos ? std::string::npos : e - p);
        if (!ln.empty() && ln.back() == '\r') ln.pop_back();
        lines.push_back(ln);
        if (e == std::string::npos) break;
        p = e + 1;
    }
    while (!lines.empty() && lines.back().empty()) lines.pop_back();
    bool found = false;
    for (auto& ln : lines) {
        std::string t = trim(ln);
        if (t.empty() || t[0] == '#') continue;
        size_t eq = t.find('=');
        if (eq == std::string::npos) continue;
        if (trim(t.substr(0, eq)) == key) { ln = key + "=" + value; found = true; }
    }
    if (!found && create) lines.push_back(key + "=" + value);
    std::string o;
    for (auto& ln : lines) o += ln + "\r\n";
    return o;
}

// ---------------------------------------------------------------- быстрые локальные команды (без обращения к ИИ)
// Самые частые просьбы выполняются мгновенно и надёжно, а всё остальное уходит модели.
inline std::string norm_cmd(const std::string& in) {
    std::string l = lower_utf8(in), o;
    for (size_t i = 0; i < l.size(); ++i) {
        unsigned char c = (unsigned char)l[i];
        if (c == 0xD1 && i + 1 < l.size() && (unsigned char)l[i + 1] == 0x91) { o += (char)0xD0; o += (char)0xB5; ++i; continue; }  // ё -> е
        if (c == 0xE2 && i + 2 < l.size()) { o += ' '; i += 2; continue; }
        if (c == 0xC2 && i + 1 < l.size()) { o += ' '; i += 1; continue; }
        if (c < 0x80) {
            if (c == '.') {
                bool inner = i > 0 && i + 1 < l.size() && !std::isspace((unsigned char)l[i - 1]) && !std::isspace((unsigned char)l[i + 1]) && l[i + 1] != '.';
                o += inner ? '.' : ' ';
            } else if (std::ispunct(c) && c != '+' && c != '#') o += ' ';
            else o += (char)c;
            continue;
        }
        o += (char)c;
    }
    return o;
}
inline std::vector<std::string> split_words(const std::string& s) {
    std::vector<std::string> w;
    std::string cur;
    for (char c : s) {
        if (std::isspace((unsigned char)c)) { if (!cur.empty()) { w.push_back(cur); cur.clear(); } }
        else cur += c;
    }
    if (!cur.empty()) w.push_back(cur);
    return w;
}
inline bool one_of(const std::string& s, std::initializer_list<const char*> l) {
    for (const char* x : l) if (s == x) return true;
    return false;
}
inline bool starts_with(const std::string& s, const char* p) { return s.compare(0, std::strlen(p), p) == 0; }
inline std::string join_words(const std::vector<std::string>& w, size_t from = 0) {
    std::string o;
    for (size_t i = from; i < w.size(); ++i) o += (o.empty() ? "" : " ") + w[i];
    return o;
}
inline bool is_yt_word(const std::string& s) {
    return starts_with(s, "ютуб") || starts_with(s, "ютюб") || starts_with(s, "ютьюб") || starts_with(s, "youtube") || starts_with(s, "юту");
}
inline bool is_music_word(const std::string& s) {
    return one_of(s, {"песню", "песня", "песни", "трек", "треки", "музыку", "музыка", "клип", "клипы", "композицию", "альбом", "плейлист", "саундтрек", "хиты", "хит"});
}
inline bool is_known_app_word(const std::string& s) {
    return one_of(s, {"chrome", "хром", "телеграм", "telegram", "дискорд", "discord", "блокнот", "калькулятор", "ворд", "word", "эксель", "excel",
                      "спотифай", "spotify", "стим", "steam", "браузер", "проводник", "пейнт", "настройки", "параметры", "диспетчер", "vscode",
                      "edge", "эдж", "firefox", "опера", "яндекс", "whatsapp", "ватсап", "zoom", "зум", "obs", "обс", "камеру", "камера"});
}
inline std::string after_word(const std::string& raw, const std::string& word) {
    std::string l = lower_utf8(raw);
    size_t p = l.find(word);
    if (p == std::string::npos) return "";
    std::string r = trim(raw.substr(p + word.size()));
    while (!r.empty() && (r[0] == ':' || r[0] == ',' || r[0] == '-' || r[0] == ' ')) r.erase(0, 1);
    if (lower_utf8(r).compare(0, 7, "что ") == 0) r = r.substr(7);
    return trim(r);
}

// ---------------------------------------------------------------- ГЕО (поиск места, координаты, карта)
struct GeoHit {
    bool ok = false, hasBox = false;
    double lat = 0, lon = 0, south = 0, north = 0, west = 0, east = 0;
    std::string name, type;
};

inline bool geo_valid(double lat, double lon) { return std::fabs(lat) <= 90.0 && std::fabs(lon) <= 180.0; }

// градусы[, минуты[, секунды]] -> десятичные градусы (знак берётся у градусов)
inline double geo_dms(const std::vector<double>& pp) {
    double v = 0, d = 1;
    for (double x : pp) { v += std::fabs(x) / d; d *= 60; }
    return (!pp.empty() && pp[0] < 0) ? -v : v;
}

// Координаты из текста: «41.31, 69.24», «41.3111 N 69.2797 E», «41°18'40"N 69°16'47"E», «широта 41,31 долгота 69,24»
inline bool geo_parse_coords(const std::string& in, double& lat, double& lon) {
    std::string s = lower_utf8(in), t;
    bool dms = false;
    for (size_t i = 0; i < s.size(); ++i) {  // знаки градусов/минут/секунд -> пробелы
        unsigned char c = (unsigned char)s[i];
        if (c == 0xC2 && i + 1 < s.size() && (unsigned char)s[i + 1] == 0xB0) { dms = true; t += ' '; ++i; }
        else if (c == 0xE2 && i + 2 < s.size() && (unsigned char)s[i + 1] == 0x80) { dms = true; t += ' '; i += 2; }
        else if (c == '\'' || c == '"') { dms = true; t += ' '; }
        else t += (char)c;
    }
    // запятая: десятичная («41,31 69,24») или разделитель («41.31, 69.24»)
    bool hasDot = t.find('.') != std::string::npos, semi = t.find(';') != std::string::npos;
    int tight = 0;
    for (size_t i = 1; i + 1 < t.size(); ++i)
        if (t[i] == ',' && std::isdigit((unsigned char)t[i - 1]) && std::isdigit((unsigned char)t[i + 1])) ++tight;
    for (size_t i = 0; i < t.size(); ++i) {
        if (t[i] == ';') t[i] = ' ';
        else if (t[i] == ',') {
            bool between = i > 0 && i + 1 < t.size() && std::isdigit((unsigned char)t[i - 1]) && std::isdigit((unsigned char)t[i + 1]);
            t[i] = (between && !hasDot && (semi || tight >= 2)) ? '.' : ' ';
        }
    }
    struct Tok { bool num; double v; char h; };  // h: 'N','S','E','W' или 0
    std::vector<Tok> toks;
    size_t i = 0;
    while (i < t.size()) {
        unsigned char c = (unsigned char)t[i];
        if (std::isspace(c)) { ++i; continue; }
        if (std::isdigit(c) || ((c == '-' || c == '+' || c == '.') && i + 1 < t.size() && (std::isdigit((unsigned char)t[i + 1]) || t[i + 1] == '.'))) {
            char* e = nullptr;
            double v = std::strtod(t.c_str() + i, &e);
            size_t n = (size_t)(e - (t.c_str() + i));
            if (n == 0) return false;
            toks.push_back({true, v, 0});
            i += n;
            continue;
        }
        size_t j = i;  // слово
        while (j < t.size() && !std::isspace((unsigned char)t[j]) && !std::isdigit((unsigned char)t[j]) && t[j] != '-' && t[j] != '+') ++j;
        if (j == i) return false;
        std::string w = t.substr(i, j - i);
        i = j;
        char h = 0;
        if (w == "n" || w == "\xD1\x81") h = 'N';
        else if (w == "s" || w == "\xD1\x8E") h = 'S';
        else if (w == "e" || w == "\xD0\xB2") h = 'E';
        else if (w == "w" || w == "\xD0\xB7") h = 'W';
        else if (w == "\xD1\x88\xD0\xB8\xD1\x80\xD0\xBE\xD1\x82\xD0\xB0" || w == "\xD0\xB4\xD0\xBE\xD0\xBB\xD0\xB3\xD0\xBE\xD1\x82\xD0\xB0" || w == "lat" || w == "lon" || w == "lng" ||
                 w == "latitude" || w == "longitude" || w == "gps" || w == "coords" || w == "\xD0\xBA\xD0\xBE\xD0\xBE\xD1\x80\xD0\xB4\xD0\xB8\xD0\xBD\xD0\xB0\xD1\x82\xD1\x8B" || w == "=" || w == ":")
            continue;
        else return false;  // посторонние слова: это не координаты, а название места
        toks.push_back({false, 0, h});
    }
    // собираем значения по координатам
    std::vector<double> vals;
    std::vector<char> hem;
    std::vector<double> parts;
    size_t nums = 0;
    for (auto& k : toks) if (k.num) ++nums;
    if (nums < 2) return false;
    if (!dms) {
        if (nums != 2) return false;
        for (size_t q = 0; q < toks.size(); ++q) {
            if (toks[q].num) { vals.push_back(toks[q].v); hem.push_back(0); }
            else if (!hem.empty() && hem.back() == 0) hem.back() = toks[q].h;
            else return false;
        }
    } else {
        size_t per = 0;  // сколько чисел в одной координате, если нет букв сторон света
        bool anyH = false;
        for (auto& k : toks) if (!k.num) anyH = true;
        if (!anyH) { if (nums == 2) per = 1; else if (nums == 4) per = 2; else if (nums == 6) per = 3; else return false; }
        for (size_t q = 0; q < toks.size(); ++q) {
            if (toks[q].num) {
                parts.push_back(toks[q].v);
                if (!anyH && parts.size() == per) {
                    vals.push_back(geo_dms(parts)); hem.push_back(0); parts.clear();
                }
            } else {
                if (parts.empty() || parts.size() > 3) return false;
                vals.push_back(geo_dms(parts)); hem.push_back(toks[q].h); parts.clear();
            }
        }
        if (!parts.empty()) return false;
    }
    if (vals.size() != 2) return false;
    double a = vals[0], b = vals[1];
    char ha = hem[0], hb = hem[1];
    bool swap = (ha == 'E' || ha == 'W') || (hb == 'N' || hb == 'S');
    if (ha == 'S' || ha == 'W') a = -std::fabs(a);
    if (hb == 'S' || hb == 'W') b = -std::fabs(b);
    if (swap) std::swap(a, b);
    if (!geo_valid(a, b)) return false;
    lat = a; lon = b;
    return true;
}

// Дробные координаты тайла OpenStreetMap (Web Mercator)
inline void geo_tile(double lat, double lon, int z, double& tx, double& ty) {
    const double PI = 3.14159265358979323846;
    lat = std::max(-85.0511, std::min(85.0511, lat));
    double n = std::ldexp(1.0, z), r = lat * PI / 180.0;
    tx = (lon + 180.0) / 360.0 * n;
    ty = (1.0 - std::log(std::tan(r) + 1.0 / std::cos(r)) / PI) / 2.0 * n;
}

// Масштаб карты по размеру найденного объекта (градусы): город ~ 10-12, улица ~ 16, здание ~ 17
inline int geo_zoom_for_span(double latSpan, double lonSpan) {
    double span = std::max(std::fabs(latSpan), std::fabs(lonSpan));
    if (span <= 0.00001) return 16;
    int z = (int)std::floor(std::log2(720.0 / span));
    return std::max(3, std::min(17, z));
}

inline std::string geo_fmt_coord(double v, bool isLat) {
    char b[64];
    std::snprintf(b, sizeof b, "%.5f\xC2\xB0 %c", std::fabs(v), isLat ? (v >= 0 ? 'N' : 'S') : (v >= 0 ? 'E' : 'W'));
    return b;
}

// Короткое название для озвучки: первые две части display_name
inline std::string geo_short_name(const std::string& full) {
    size_t c1 = full.find(", ");
    if (c1 == std::string::npos) return full;
    size_t c2 = full.find(", ", c1 + 2);
    return c2 == std::string::npos ? full : full.substr(0, c2);
}

// Ответ Nominatim (search: массив, reverse: объект) -> GeoHit
inline bool geo_parse_nominatim(const std::string& body, GeoHit& h) {
    Json j;
    if (!json_parse(body, j)) return false;
    const Json* r = &j;
    if (j.t == Json::Arr) r = &j.at(0);
    if (r->t != Json::Obj || (*r)["error"].t != Json::Null) return false;
    std::string la = (*r)["lat"].str(), lo = (*r)["lon"].str();
    if (la.empty() || lo.empty()) return false;
    h.lat = std::atof(la.c_str());
    h.lon = std::atof(lo.c_str());
    if (!geo_valid(h.lat, h.lon)) return false;
    h.name = (*r)["display_name"].str();
    h.type = (*r)["addresstype"].str();
    if (h.type.empty()) h.type = (*r)["type"].str();
    const Json& bb = (*r)["boundingbox"];
    if (bb.t == Json::Arr && bb.a.size() == 4) {
        h.south = std::atof(bb.at(0).str().c_str()); h.north = std::atof(bb.at(1).str().c_str());
        h.west = std::atof(bb.at(2).str().c_str());  h.east = std::atof(bb.at(3).str().c_str());
        h.hasBox = true;
    }
    h.ok = true;
    return true;
}

// Голосовые фразы про карту: «покажи на карте Ташкент», «где находится Эйфелева башня», «координаты 41.31, 69.24», «закрой карту»
inline bool geo_intent(const std::string& raw, Action& act) {
    std::string l = lower_utf8(raw);
    const std::string& src = (l.size() == raw.size()) ? raw : l;
    auto has = [&](const char* p) { return l.find(p) != std::string::npos; };
    if (has("закрой карту") || has("закрой глобус") || has("убери карту") || has("убери глобус") || has("скрой карту") || has("скрой глобус") ||
        has("закрыть карту") || has("закрой гео") || has("закрой геопоиск")) {
        act = Action(); act.type = "geo_close";
        return true;
    }
    static const char* kTrig[] = {"на карте", "на глобусе", "на земле", "где находится", "где находятся", "где расположен", "где расположена", "где расположено",
                                  "найди адрес", "покажи адрес", "геопоиск", "гео поиск", "найди координаты", "координаты", "геолокация", "геолокацию"};
    size_t pos = std::string::npos, len = 0;
    int ti = -1;
    for (int i = 0; i < (int)(sizeof kTrig / sizeof kTrig[0]); ++i) {
        size_t p = l.find(kTrig[i]);
        if (p != std::string::npos && (pos == std::string::npos || p < pos)) { pos = p; len = std::strlen(kTrig[i]); ti = i; }
    }
    if (pos == std::string::npos) return false;
    bool verb = has("покаж") || has("найд") || has("отмет") || has("поищ") || has("ищи") || has("открой") || has("где ") || has("покажи");
    if (ti <= 2 && !verb) return false;
    static const char* kNotGeo[] = {"файл", "папк", "программ", "приложен", "документ", "кнопк", "настройк", "карте памяти", "видеокарт", "карта памяти", "на карте sd"};
    for (const char* x : kNotGeo) if (has(x)) return false;
    auto clean = [](const std::string& s) {
        std::vector<std::string> w = split_words(s);
        auto key = [](std::string x) {
            x = lower_utf8(x);
            while (!x.empty() && (x.back() == ',' || x.back() == '.' || x.back() == '!' || x.back() == '?' || x.back() == ':' || x.back() == ';')) x.pop_back();
            return x;
        };
        static const std::initializer_list<const char*> kFill = {"покажи", "показать", "найди", "найти", "отметь", "поищи", "ищи", "открой", "мне", "нам", "пожалуйста", "флей", "давай",
                                                                  "где", "находится", "находятся", "расположен", "расположена", "расположено", "у", "для", "по", "какие", "какой", "что", "это",
                                                                  "адрес", "координаты", "координатам", "ка", "точку", "точный", "место", "на", "карте", "глобусе", "земле", "геопоиск", "гео", "поиск"};
        size_t b = 0, e = w.size();
        while (b < e && one_of(key(w[b]), kFill)) ++b;
        while (e > b && one_of(key(w[e - 1]), {"пожалуйста", "плиз", "флей", "на", "карте", "глобусе", "земле", "мне", "ка"})) --e;
        std::string o;
        for (size_t i = b; i < e; ++i) o += (o.empty() ? "" : " ") + w[i];
        return trim(o);
    };
    std::string before = clean(src.substr(0, pos)), after = clean(src.substr(pos + len));
    std::string q = !after.empty() ? after : before;
    if (!after.empty() && !before.empty() && ti <= 2 && after.size() < 3) q = before;
    while (!q.empty() && (q.back() == '?' || q.back() == '!' || q.back() == '.' || q.back() == ',' || q.back() == ' ')) q.pop_back();
    if (q.size() < 2) return false;
    act = Action(); act.type = "geo"; act.args.push_back(q);
    return true;
}

// ---------------------------------------------------------------- музыкальный плеер: разбор ответов сервисов и голосовые фразы
// Источники без ключей: Audius (полные треки) и Deezer (отрывки по 30 секунд).
struct MusicTrack {
    std::string id, title, artist, url, source;  // source: audius (полный трек) или deezer (отрывок 30 с)
    int secs = 0;
    bool full = false;
};

inline std::string music_fmt_time(long secs) {
    if (secs < 0) secs = 0;
    char b[32];
    std::snprintf(b, sizeof b, "%ld:%02ld", secs / 60, secs % 60);
    return b;
}

inline bool music_safe_id(const std::string& id) {
    if (id.empty() || id.size() > 40) return false;
    for (unsigned char c : id) if (!std::isalnum(c) && c != '_' && c != '-') return false;
    return true;
}

// Audius: {"data":[{"id":"D7KyD","title":"...","duration":187,"user":{"name":"..."},"is_streamable":true}]}
inline bool music_parse_audius(const std::string& body, std::vector<MusicTrack>& out, size_t maxN) {
    Json j;
    if (!json_parse(body, j)) return false;
    const Json& d = j["data"];
    if (d.t != Json::Arr) return false;
    for (const Json& t : d.a) {
        if (out.size() >= maxN) break;
        std::string id = t["id"].str();
        if (!music_safe_id(id)) continue;
        if (t["is_streamable"].t == Json::Bool && !t["is_streamable"].b) continue;
        if (t["access"]["stream"].t == Json::Bool && !t["access"]["stream"].b) continue;  // платные и закрытые треки
        MusicTrack m;
        m.title = trim(t["title"].str());
        if (m.title.empty()) continue;
        m.id = id;
        m.artist = trim(t["user"]["name"].str());
        m.secs = (int)t["duration"].n;
        m.url = "https://api.audius.co/v1/tracks/" + id + "/stream?app_name=FLEY_AI";
        m.source = "audius";
        m.full = true;
        out.push_back(m);
    }
    return true;
}

// Deezer: {"data":[{"id":3135556,"title":"...","duration":224,"preview":"https://...mp3","artist":{"name":"..."}}]}
inline bool music_parse_deezer(const std::string& body, std::vector<MusicTrack>& out, size_t maxN) {
    Json j;
    if (!json_parse(body, j)) return false;
    if (j["error"].t != Json::Null) return false;
    const Json& d = j["data"];
    if (d.t != Json::Arr) return false;
    for (const Json& t : d.a) {
        if (out.size() >= maxN) break;
        std::string url = t["preview"].str();
        if (!is_http_url(url)) continue;
        MusicTrack m;
        m.title = trim(t["title"].str());
        if (m.title.empty()) continue;
        m.id = t["id"].t == Json::Num ? std::to_string((long long)t["id"].n) : t["id"].str();
        m.artist = trim(t["artist"]["name"].str());
        m.secs = 30;  // Deezer отдаёт только отрывок
        m.url = url;
        m.source = "deezer";
        m.full = false;
        out.push_back(m);
    }
    return true;
}

// «включи песню Believer», «найди трек numb», «открой плеер», «закрой плеер», «включи музыку».
// Фразы про YouTube, клипы, видео и известные программы (Spotify и т.п.) сюда не попадают.
inline bool music_intent(const std::vector<std::string>& w, Action& act) {
    if (w.empty()) return false;
    auto has = [&](const char* x) { for (const std::string& t : w) if (t == x) return true; return false; };
    auto set = [&](const char* type, std::initializer_list<std::string> args) { act = Action(); act.type = type; act.args.assign(args.begin(), args.end()); return true; };
    for (const std::string& t : w) if (is_yt_word(t) || is_known_app_word(t)) return false;
    if (has("клип") || has("клипы") || has("видео") || has("ролик")) return false;
    bool player = has("плеер") || has("плеере") || has("плеера") || has("проигрыватель") || has("проигрывателе") || has("проигрывателя");
    bool musicw = false;
    for (const std::string& t : w) if (is_music_word(t) && !one_of(t, {"клип", "клипы"})) musicw = true;
    if (!player && !musicw) return false;
    const std::string& v = w[0];
    if (player && one_of(v, {"закрой", "закрыть", "выключи", "выключить", "убери", "скрой", "отключи"})) return set("music_close", {});
    // «включи следующую песню», «поставь музыку на паузу»: это управление, а не поиск
    if (has("следующую") || has("следующий") || has("следующая") || has("дальше") || has("другую") || has("другой")) return set("media", {"next"});
    if (has("предыдущую") || has("предыдущий") || has("предыдущая")) return set("media", {"prev"});
    if (has("паузу") || has("пауза") || has("паузе")) return set("media", {"play_pause"});
    if (has("громче") || has("тише") || has("погромче") || has("потише") || has("громкость") || has("громкости")) return false;

    bool playV = one_of(v, {"включи", "поставь", "врубай", "воспроизведи", "сыграй", "запусти", "включить", "поставить", "запустить"});
    bool findV = one_of(v, {"найди", "поищи", "ищи", "найти", "покажи"});
    bool openV = one_of(v, {"открой", "открыть", "включи", "включить", "запусти", "запустить", "покажи"});
    if (!playV && !findV && !openV) return false;
    static const std::initializer_list<const char*> kStop = {
        "на", "в", "во", "и", "мне", "там", "пожалуйста", "что", "нибудь", "какую", "какой", "любую", "любой", "по", "названию", "название", "под", "с", "из",
        "плеере", "плеер", "плеера", "проигрывателе", "проигрыватель", "проигрывателя", "музыкальном", "музыкальный", "музыкального",
        "песню", "песня", "песни", "трек", "треки", "музыку", "музыка", "композицию", "хиты", "хит", "найди", "поищи", "ищи", "включи", "поставь", "сыграй", "ка", "давай"};
    std::vector<std::string> q;
    for (size_t i = 1; i < w.size(); ++i) {
        bool stop = false;
        for (const char* sw : kStop) if (w[i] == sw) stop = true;
        if (!stop) q.push_back(w[i]);
    }
    if (q.empty() && (openV || findV)) {
        if (playV && musicw && !player) return set("music", {"", "play"});  // «включи музыку» - популярное
        return set("music", {"", "idle"});                                   // «открой плеер»
    }
    if (q.empty()) return false;
    return set("music", {join_words(q), playV ? "play" : "list"});
}

inline bool local_intent(const std::string& raw, Action& act) {
    std::vector<std::string> w = split_words(norm_cmd(raw));
    size_t b = 0;
    while (b < w.size() && one_of(w[b], {"флей", "флэй", "фли", "fley", "джарвис", "jarvis", "эй", "слушай", "ну", "давай", "можешь", "можете", "сейчас", "а", "и", "так", "итак", "ладно", "пожалуйста", "мне", "привет"})) ++b;
    size_t e = w.size();
    while (e > b && one_of(w[e - 1], {"пожалуйста", "плиз", "ладно", "быстро", "сейчас", "флей"})) --e;
    w = std::vector<std::string>(w.begin() + (long)b, w.begin() + (long)e);
    if (w.empty()) return false;
    std::string n = join_words(w), pad = " " + n + " ";
    auto has = [&](const char* ph) { return pad.find(std::string(" ") + ph + " ") != std::string::npos; };
    auto set = [&](const char* type, std::initializer_list<std::string> args = {}) { act = Action(); act.type = type; act.args.assign(args.begin(), args.end()); return true; };
    const std::string& v = w[0];

    // микрофон / питание
    if (has("выключи микрофон") || has("отключи микрофон") || has("хватит слушать") || has("перестань слушать") || has("не слушай") || has("засыпай") ||
        has("отключись") || has("до свидания") || has("спокойной ночи") || (w.size() <= 2 && v == "пока"))
        return set("mic_off");
    if (has("отмени выключение") || has("отмени перезагрузку") || has("отмени завершение работы")) return set("power", {"cancel"});
    if (starts_with(v, "заблокируй") || has("блокировка экрана") || has("заблокировать компьютер")) return set("lock");

    // запомни / забудь
    if (v == "запомни" && w.size() > 1) { std::string f = after_word(raw, "запомни"); if (!f.empty()) return set("remember", {f}); }
    if (v == "забудь" && w.size() > 1) { std::string f = after_word(raw, "забудь"); if (!f.empty()) return set("forget", {f}); }

    // карта / геопоиск
    { Action ga; if (geo_intent(raw, ga)) { act = ga; return true; } }

    // громкость
    {
        int num = -1;
        for (auto& t : w) if (!t.empty() && std::isdigit((unsigned char)t[0])) num = std::atoi(t.c_str());
        bool volWord = false;
        for (auto& t : w) if (t == "громкость" || t == "звук" || t == "громкости") volWord = true;
        if (volWord && num >= 0 && num <= 100) return set("volume", {"set", std::to_string(num)});
        if (has("выключи звук") || has("отключи звук") || has("выруби звук") || has("без звука")) return set("volume", {"mute"});
        if (one_of(v, {"громче", "погромче"}) || has("сделай громче") || has("сделай погромче") || has("прибавь звук") || has("добавь звук") || has("прибавь громкость") ||
            has("добавь громкость") || has("увеличь громкость") || has("увеличь звук"))
            return set("volume", {"up", "8"});
        if (one_of(v, {"тише", "потише"}) || has("сделай тише") || has("сделай потише") || has("убавь звук") || has("убавь громкость") || has("уменьши громкость") || has("уменьши звук"))
            return set("volume", {"down", "8"});
    }
    // медиа
    if (one_of(n.c_str(), {"следующий трек", "следующая песня", "следующий", "следующую", "дальше", "переключи трек", "включи следующий", "следующее видео", "следующая"}))
        return set("media", {"next"});
    if (one_of(n.c_str(), {"предыдущий трек", "предыдущая песня", "предыдущий", "прошлый трек", "прошлая песня", "предыдущую"})) return set("media", {"prev"});
    if (one_of(n.c_str(), {"пауза", "на паузу", "поставь на паузу", "продолжи", "продолжай", "возобнови", "останови музыку", "останови видео", "пауза видео", "пауза музыка", "play", "стоп музыка"}))
        return set("media", {"play_pause"});

    // музыкальный плеер (встроенный): «включи песню ...», «найди трек ...», «открой плеер»
    { Action ma; if (music_intent(w, ma)) { act = ma; return true; } }

    static const std::initializer_list<const char*> kPlayVerbs = {"включи", "поставь", "врубай", "воспроизведи", "сыграй", "включить", "поставить", "запусти", "запустить", "открой", "покажи"};
    static const std::initializer_list<const char*> kStop = {"на", "в", "во", "и", "мне", "для", "там", "видео", "ролик", "через", "с", "помощью", "по", "пожалуйста", "что-нибудь", "что", "нибудь", "канале", "сайте", "mp3"};

    // YouTube
    size_t yt = w.size();
    for (size_t i = 0; i < w.size(); ++i) if (is_yt_word(w[i])) { yt = i; break; }
    if (yt < w.size()) {
        bool play = one_of(v, {"включи", "поставь", "запусти", "воспроизведи", "врубай", "включить", "поставить", "запустить", "сыграй", "покажи"});
        bool search = one_of(v, {"найди", "поищи", "ищи", "найти", "поиск"});
        bool open = one_of(v, {"открой", "зайди", "открыть", "перейди"});
        if (play || search || open) {
            std::vector<std::string> q;
            for (size_t i = 1; i < w.size(); ++i) {
                if (i == yt || is_yt_word(w[i])) continue;
                bool stop = false;
                for (const char* sw : kStop) if (w[i] == sw) stop = true;
                if (!stop) q.push_back(w[i]);
            }
            if (q.empty()) return set("youtube", {""});
            bool generic = true;
            for (auto& t : q) if (!is_music_word(t)) generic = false;
            std::string query = generic ? "популярная музыка" : join_words(q);
            return play ? set("youtube_play", {query}) : set("youtube", {query});
        }
    }
    // «включи / поставь <песня>» без слова «ютуб»
    {
        bool pv = false;
        for (const char* x : kPlayVerbs) if (v == x) pv = true;
        if (pv && w.size() >= 2) {
            static const char* bad[] = {"будильник", "таймер", "напоминание", "свет", "режим", "обои", "яркость", "громкость", "звук", "паузу", "пауза", "тему", "телевизор", "кондиционер", "чайник", "wifi", "bluetooth", "блютуз", "компьютер", "файл", "папку", "сайт", "окно", "программу", "приложение"};
            bool excl = false, music = false;
            for (size_t i = 1; i < w.size(); ++i) {
                for (const char* x : bad) if (w[i] == x) excl = true;
                if (is_music_word(w[i])) music = true;
            }
            std::vector<std::string> q;
            for (size_t i = 1; i < w.size(); ++i) {
                bool stop = false;
                for (const char* sw : kStop) if (w[i] == sw) stop = true;
                if (!stop) q.push_back(w[i]);
            }
            bool softVerb = one_of(v, {"включи", "поставь", "врубай", "воспроизведи", "сыграй", "включить", "поставить"});
            if (!excl && !q.empty() && (music || (softVerb && q.size() >= 2 && !is_known_app_word(q[0])))) {
                bool generic = true;
                for (auto& t : q) if (!is_music_word(t)) generic = false;
                return set("youtube_play", {generic ? std::string("популярная музыка") : join_words(q)});
            }
        }
    }
    // Google
    if (v == "загугли" && w.size() > 1) return set("search", {join_words(w, 1)});
    if (one_of(v, {"найди", "поищи", "ищи", "найти"})) {
        bool g = false;
        for (auto& t : w) if (starts_with(t, "гугл") || starts_with(t, "google") || starts_with(t, "интернет")) g = true;
        if (g) {
            std::vector<std::string> q;
            for (size_t i = 1; i < w.size(); ++i)
                if (!one_of(w[i], {"в", "на", "во", "гугле", "гугл", "google", "интернете", "сети", "мне", "информацию", "интернет"})) q.push_back(w[i]);
            if (!q.empty()) return set("search", {join_words(q)});
        }
    }
    // открыть программу / папку / сайт
    if (one_of(v, {"открой", "открыть", "запусти", "запустить", "включи", "включить"})) {
        std::vector<std::string> q;
        for (size_t i = 1; i < w.size(); ++i)
            if (!one_of(w[i], {"программу", "приложение", "мне", "на", "компьютере", "окно", "браузере", "пожалуйста"})) q.push_back(w[i]);
        if (q.empty() || q.size() > 3) return false;
        bool soft = one_of(v, {"включи", "включить"});
        if (soft && !is_known_app_word(q[0])) return false;
        if (one_of(q[0], {"папку", "папка", "каталог", "директорию"})) {
            if (q.size() < 2) return false;
            return set("open_path", {join_words(q, 1)});
        }
        for (auto& t : q) if (t == "сайт" || t == "файл" || t == "документ") return false;
        if (q.size() == 1 && q[0].find('.') != std::string::npos && q[0].size() > 3) {
            std::string u = q[0];
            if (!starts_with(u, "http")) u = "https://" + u;
            return set("open_url", {u});
        }
        return set("open_app", {join_words(q)});
    }
    return false;
}

// Короткая фраза, которую FLEY произносит после выполнения локальной команды
inline std::string local_ack(const Action& a) {
    const std::string a0 = a.args.empty() ? "" : a.args[0];
    if (a.type == "youtube_play") return "Включаю.";
    if (a.type == "geo") return "Ищу на карте.";
    if (a.type == "geo_close") return "Закрываю карту.";
    if (a.type == "music") return a0.empty() ? "Открываю плеер." : "Ищу музыку.";
    if (a.type == "music_close") return "Закрываю плеер.";
    if (a.type == "youtube") return a0.empty() ? "Открываю YouTube." : "Открываю поиск.";
    if (a.type == "open_app") return "Открываю " + a0 + ".";
    if (a.type == "open_path") return "Открываю папку.";
    if (a.type == "open_url") return "Открываю.";
    if (a.type == "search") return "Ищу.";
    if (a.type == "volume") return a0 == "up" ? "Громче." : a0 == "down" ? "Тише." : a0 == "mute" ? "Готово." : "Громкость " + (a.args.size() > 1 ? a.args[1] : std::string()) + ".";
    if (a.type == "media") return "Готово.";
    if (a.type == "lock") return "Блокирую.";
    if (a.type == "remember") return "Запомнил.";
    if (a.type == "forget") return "Забыл.";
    if (a.type == "power") return "Отменил.";
    if (a.type == "mic_off") return "Отключаюсь. Позовите, когда понадоблюсь.";
    return "Готово.";
}


// «Please try again in 7m12.5s» / «850ms» / «1h2m3s» -> секунды (0, если не найдено)
inline int parse_retry_seconds(const std::string& body) {
    size_t p = body.find("try again in ");
    if (p == std::string::npos) return 0;
    const char* c = body.c_str() + p + 13;
    double total = 0;
    for (;;) {
        char* e = nullptr;
        double v = std::strtod(c, &e);
        if (e == c) break;
        c = e;
        if (c[0] == 'm' && c[1] == 's') { total += v / 1000.0; c += 2; }
        else if (c[0] == 'm') { total += v * 60.0; c += 1; }
        else if (c[0] == 'h') { total += v * 3600.0; c += 1; }
        else if (c[0] == 's') { total += v; c += 1; }
        else break;
    }
    return (int)std::ceil(total);
}


// ---------------------------------------------------------------- зрение: экран -> модель с картинками
inline std::string base64_encode(const std::string& in) {
    static const char* t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string o;
    o.reserve((in.size() + 2) / 3 * 4);
    size_t i = 0;
    for (; i + 2 < in.size(); i += 3) {
        uint32_t v = ((uint8_t)in[i] << 16) | ((uint8_t)in[i + 1] << 8) | (uint8_t)in[i + 2];
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += t[(v >> 6) & 63]; o += t[v & 63];
    }
    if (i + 1 == in.size()) {
        uint32_t v = (uint8_t)in[i] << 16;
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += "==";
    } else if (i + 2 == in.size()) {
        uint32_t v = ((uint8_t)in[i] << 16) | ((uint8_t)in[i + 1] << 8);
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += t[(v >> 6) & 63]; o += '=';
    }
    return o;
}

// Размер картинки для отправки: длинная сторона не больше max_side, пропорции сохраняются
inline void fit_size(int w, int h, int max_side, int& ow, int& oh) {
    ow = w; oh = h;
    int m = std::max(w, h);
    if (m <= max_side || m <= 0) return;
    double k = (double)max_side / m;
    ow = std::max(1, (int)std::lround(w * k));
    oh = std::max(1, (int)std::lround(h * k));
}

// Тело запроса chat/completions с одной картинкой (data-URI) и вопросом
inline std::string vision_body(const std::string& model, const std::string& prompt, const std::string& mime, const std::string& b64,
                               int max_tokens, bool use_max_tokens, const std::string& extra = "") {
    return "{\"model\":\"" + json_escape(model) + "\",\"" + (use_max_tokens ? "max_tokens" : "max_completion_tokens") + "\":" + std::to_string(max_tokens) + "," + extra +
           "\"messages\":[{\"role\":\"user\",\"content\":[{\"type\":\"text\",\"text\":\"" + json_escape(prompt) +
           "\"},{\"type\":\"image_url\",\"image_url\":{\"url\":\"data:" + mime + ";base64," + b64 + "\"}}]}]}";
}

// Текст ответа модели: content может быть строкой или списком частей; <think>…</think> вырезаем
inline std::string vision_extract_text(const Json& j) {
    const Json& c = j["choices"].at(0)["message"]["content"];
    std::string t;
    if (c.t == Json::Str) t = c.s;
    else if (c.t == Json::Arr) for (const Json& p : c.a) t += p["text"].str();
    for (;;) {
        size_t a = t.find("<think>");
        if (a == std::string::npos) break;
        size_t b = t.find("</think>", a);
        t.erase(a, b == std::string::npos ? std::string::npos : b + 8 - a);
    }
    return trim(t);
}

// Достаёт числа из текста вида {"x":512,"y":300} / (512, 300) / [512,300] / [x1,y1,x2,y2] (берётся центр рамки).
inline bool vision_numbers(const std::string& s, std::vector<double>& out) {
    out.clear();
    size_t i = 0;
    while (i < s.size() && out.size() < 8) {
        if (std::isdigit((unsigned char)s[i]) || ((s[i] == '-' || s[i] == '.') && i + 1 < s.size() && std::isdigit((unsigned char)s[i + 1]))) {
            char* e = nullptr;
            double v = std::strtod(s.c_str() + i, &e);
            if (e == s.c_str() + i) { ++i; continue; }
            out.push_back(v);
            i = (size_t)(e - s.c_str());
        } else ++i;
    }
    return !out.empty();
}
// Координаты точки как доли экрана 0..1. Модель просят отвечать в сетке 0..1000; если числа больше 1000 - это пиксели отправленной картинки (img_w x img_h).
inline bool vision_parse_point(const std::string& text, int img_w, int img_h, double& fx, double& fy) {
    std::string t = to_lower_ascii(text);
    if (t.find("not found") != std::string::npos || t.find("не найден") != std::string::npos || t.find("null") != std::string::npos || t.find("none") != std::string::npos) return false;
    std::vector<double> n;
    size_t kx = t.find("\"x\""), ky = t.find("\"y\"");
    if (kx != std::string::npos && ky != std::string::npos) {   // JSON с ключами x и y (порядок любой)
        std::vector<double> a, b;
        vision_numbers(t.substr(kx + 3, 24), a);
        vision_numbers(t.substr(ky + 3, 24), b);
        if (a.empty() || b.empty()) return false;
        n = {a[0], b[0]};
    } else if (!vision_numbers(text, n)) return false;
    double x, y;
    if (n.size() >= 4) { x = (n[0] + n[2]) / 2; y = (n[1] + n[3]) / 2; }
    else if (n.size() >= 2) { x = n[0]; y = n[1]; }
    else return false;
    if (x < 0 || y < 0) return false;
    if (x <= 1.0 && y <= 1.0) { fx = x; fy = y; return true; }                 // уже доли
    if (x <= 1000.0 && y <= 1000.0) { fx = x / 1000.0; fy = y / 1000.0; return true; }   // сетка 0..1000
    if (img_w <= 0 || img_h <= 0 || x > img_w * 1.05 || y > img_h * 1.05) return false;   // пиксели картинки
    fx = std::min(1.0, x / img_w); fy = std::min(1.0, y / img_h);
    return true;
}

// Насколько модель похожа на модель с картинками (0 - не подходит). Нужна, когда названия моделей у провайдера поменялись.
inline int vision_model_rank(const std::string& id0) {
    std::string id = to_lower_ascii(id0);
    for (const char* bad : {"whisper", "tts", "guard", "embed", "orpheus", "moderation", "transcribe", "audio", "safeguard", "rerank", "image-gen", "dall"})
        if (id.find(bad) != std::string::npos) return 0;
    auto has = [&](const char* x) { return id.find(x) != std::string::npos; };
    if (has("vision") || has("-vl") || has("_vl")) return 90;
    if (has("llama-4") || has("pixtral") || has("muse-spark")) return 85;
    if (has("gpt-4o") || has("gpt-4.1") || has("gpt-5") || has("gemini") || has("claude") || has("grok") || has("o4-mini")) return 80;
    if (has("qwen3.5") || has("qwen3.6") || has("qwen3.7") || has("qwen3.8") || has("qwen3.9") || has("qwen4") || has("qwen2.5-vl")) return 75;
    if (has("gemma-3") || has("gemma3") || has("llava") || has("minicpm") || has("internvl")) return 60;
    return 0;
}
// Из ответа GET /models выбирает до max_n подходящих моделей (лучшие первыми), кроме уже пробованных
inline std::vector<std::string> vision_model_candidates(const std::string& models_json, const std::vector<std::string>& skip, size_t max_n = 8) {
    std::vector<std::pair<int, std::string>> v;
    Json j;
    if (!json_parse(models_json, j) || j["data"].t != Json::Arr) return {};
    for (const Json& m : j["data"].a) {
        std::string id = m["id"].str();
        int r = vision_model_rank(id);
        if (r <= 0 || std::find(skip.begin(), skip.end(), id) != skip.end()) continue;
        v.push_back({r, id});
    }
    std::stable_sort(v.begin(), v.end(), [](const std::pair<int, std::string>& x, const std::pair<int, std::string>& y) { return x.first > y.first; });
    std::vector<std::string> out;
    for (auto& p : v) { out.push_back(p.second); if (out.size() >= max_n) break; }
    return out;
}

inline bool is_vision_action(const std::string& t) {
    return t == "see" || t == "screen" || t == "look" || t == "screen_find" || t == "find_on_screen" || t == "click_on" || t == "click" || t == "mouse_click" ||
           t == "move_mouse" || t == "mouse_move" || t == "drag" || t == "scroll" || t == "ui_list" || t == "ui_click" || t == "screen_watch";
}

// Строка списка элементов окна: «Тип|Имя|x|y|ширина|высота»
struct UiElem { std::string type, name; int x = 0, y = 0, w = 0, h = 0; };
inline bool ui_parse_line(const std::string& line0, UiElem& e) {
    std::string line = line0;
    while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
    std::vector<std::string> f;
    size_t s = 0;
    for (;;) {
        size_t t = line.find('|', s);
        if (t == std::string::npos) { f.push_back(line.substr(s)); break; }
        f.push_back(line.substr(s, t - s));
        s = t + 1;
    }
    if (f.size() < 6 || f[1].empty()) return false;
    e.type = f[0]; e.name = f[1];
    e.x = std::atoi(f[2].c_str()); e.y = std::atoi(f[3].c_str()); e.w = std::atoi(f[4].c_str()); e.h = std::atoi(f[5].c_str());
    return e.w > 0 && e.h > 0;
}

}  // namespace fley
